package com.controller;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.service.*;

import com.model.BookRestaurant;

//use appropriate annotation to configure BookController as Controller
@Controller
public class BookController {
	@Autowired
	private BookService bookService;
	//invoke the service class - calculateTotalCost method.
	@PostMapping("/billDesk")
	public String calculateTotalCost(@ModelAttribute("book") BookRestaurant book, 
			BindingResult result,ModelMap model) {
		
		//fill the code
		return "billdesk";
	}
	@GetMapping("/showPage")
	public String showPage(@ModelAttribute("book") BookRestaurant book){
		return "showpage";
	}
	
	@ModelAttribute("hallList")
	public Map<String,String> populateHallType(){
		Map<String,String>hall=new HashMap<String,String>();
		hall.put("AC", "AC");
		hall.put("NONAC","NONAC");
		
		return hall;
	}
	
}
