package com.service;

import org.springframework.stereotype.Component;

import com.model.BookRestaurant;

//use appropriate annotation to configure BookService as a Service
@Component
public class BookService {
	
	//calculate the totalCost and return the cost
	public double calculateTotalCost(BookRestaurant book) {
		
		double cost=0.0;
		//fill the code
		//int adultVegCount;
		//int adultNonVegCount;
		///int kidsVegCount;
		//int kidsNonVegCount;
		
		if(book.getHallType().equals("AC")){
			cost=cost+(book.getKidsVegCount()*599.0)+(book.getKidsVegCount()*299.0)+(book.getAdultNonVegCount()*699.0)+(book.getKidsNonVegCount()*349.0)+500.0;
			//System.out.println(cost);
			return cost;
		}
		else{
			cost=cost+(book.getKidsVegCount()*599.0)+(book.getKidsVegCount()*299.0)+(book.getAdultNonVegCount()*699.0)+(book.getKidsNonVegCount()*349.0);
			return cost;
			
			
		}
		
		
		
	}

}
